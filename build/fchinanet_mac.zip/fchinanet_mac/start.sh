c_dir=$(cd "$(dirname "$0")";pwd)
cd $c_dir
./fchinanet